﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Charger_Bolt_Link_Pro
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
        }

        private void ValInputBtn_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 20; i++)
            {
                System.Diagnostics.Debug.WriteLine("-");
            }

            System.Diagnostics.Debug.WriteLine(ValInput.Text);
            if (ValInput.Text != "")
                try
                {
                    string[] tokens = { "", "", "", "", "" };
                    tokens = (ValInput.Text).Replace(" ", "").Split(',');

                    SetStatus(Int16.Parse(tokens[0]), Int16.Parse(tokens[1]), Boolean.Parse(tokens[2]), Double.Parse(tokens[3]));
                }
                catch (Exception ex)
                {
                    Print("" + ex.ToString());
                }
            else
            {
                SetStatus(1, 1, false, 20.0);
                SetStatus(1, 5, false, 99.9);
                SetStatus(3, 5, false, 67.5);
            }
            Print("Done");

        }

        private void SetStatus(int row = 1, int col = 1, bool status = true, double tempVal = 50.0)
        {
            Ellipse e; Label l; ProgressBar p;


            String[] Red = { "#40990000", "#80990000", "#B0990000", "#FF990000" };
            String[] Grn = { "#4066FF99", "#8033CC66", "#B000CC00", "#FF00FF00" };

            for (int i = 0; i < 4; i++)
            {
                e = this.FindName("Stat" + i + "_" + row + col) as Ellipse;
                if (status)
                    e.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Grn[i]));
                else
                    e.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Red[i]));
            }
            l = this.FindName("OnlineInd" + "_" + row + col) as Label;
            if (status)
            {
                l.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Grn[3]));
                l.Content = "Online";
            }
            else
            {
                l.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Red[3]));
                l.Content = "Offline";
            }

            p = this.FindName("TempA1" + "_" + row + col) as ProgressBar;
            p.Value = tempVal;

        }

        public void Print(String str)
        {
            System.Diagnostics.Debug.WriteLine(str);
        }
    }
}
